# oVirt ansible collections
This collection works with Ansible 2.9+

# Installation
```bash
ansible-galaxy collection install mnecas.ovirt
```